import { readFile, writeFile, mkdir } from "node:fs/promises";
import { spawnSync } from "node:child_process";
import { sha } from "./common.mjs";
import { ordinaryBinarize, bundleHash } from "./diagnostic.mjs";
const root = "docs/research/prose-qr/integrated-2026-10-10/empirical",
  source = "experiments/prose-qr/integrated-2026-10-10/empirical",
  out = root + "/construction-05";
await mkdir(out, { recursive: true });
const save = async (p, v) => writeFile(p, v, { flag: "wx" }),
  json = (p, v) => save(p, JSON.stringify(v, null, 2) + "\n"),
  read = async (p) => JSON.parse(await readFile(p));
const dirs = ["regular", "bold"].map(
    (s) => root + "/layout-05/v5-reverse-" + s,
  ),
  doms = await Promise.all(dirs.map((d) => read(d + "/dom.json"))),
  receipts = await Promise.all(dirs.map((d) => read(d + "/capture.json"))),
  inputHashes = {};
for (const d of dirs)
  for (const f of [
    "input.png",
    "repeat.png",
    "source.html.txt",
    "dom.json",
    "capture.json",
  ])
    inputHashes[d + "/" + f] = sha(await readFile(d + "/" + f));
await json(out + "/preregistration.json", {
  schema: "aqrobat.integrated.native-sampling.v1",
  frozenAtUtc: new Date().toISOString(),
  amendment:
    "Amends construction-04, which stopped before construction on3 changed cells outside canvas ink-envelope pixel support by0.0449,0.4824,0.4824px. New globally conservative1px canvas-bound padding accounts for fractional native hinting uncertainty. Ambiguous groups globally fixed to regular, without changing images or sampled pixels. Fixed alignment glyph remains fixed. A later mixed capture must validate every literal prediction.",
  capturedInputs: inputHashes,
  sourceHashes: {
    [source + "/sample-v5-v2.mjs"]: sha(
      await readFile(source + "/sample-v5-v2.mjs"),
    ),
    [source + "/diagnostic.mjs"]: sha(
      await readFile(source + "/diagnostic.mjs"),
    ),
  },
  denominator: {
    moduleSamplesPerMap: 1369,
    quietSamplesPerMap: 656,
    maps: 2,
    sourceCaptures: 0,
    ordinaryCalls: 0,
    passiveProfiles: 0,
  },
  polarity:
    "Normal: native raw black is logical QR1, raw white QR0. No image transformation.",
  primary:
    "Frozen rawgray128 per-cell samples plus unique real glyph union ink bounds of measured regular/bold states. Lock all groups implicated by overlapping ownership. Complete all1369 cells. Exact native mixed style needs own capture/sample verification before decode.",
  diagnostic:
    "Pinned ordinary-jsQR adaptive binarizer sampled separately on unchanged regular and bold PNGs. Neighborhood coupling makes affine mixed prediction unsupported; diagnostic only, not solver input.",
  samplePolicy:
    "floor(origin+(index+.5)*pitch), origin64 pitch6.5 dimension37. Four-module external ring sampled identically including every656 cells; no quiet omission.",
  stops: [
    "input/source mismatch",
    "RGBA read failure",
    "source identity/position drift",
    "changed pixel with no unique glyph attribution after conservative group locks",
    "out-of-bounds sample",
  ],
});
for (let i = 0; i < 2; i++) {
  if (
    !receipts[i].repeatExact ||
    receipts[i].sourceHtmlSha256 !== inputHashes[dirs[i] + "/source.html.txt"]
  )
    throw Error("Custody");
}
const images = dirs.map((d) => {
    const r = spawnSync(
      "python3",
      [
        "-c",
        "import cv2,sys;a=cv2.imread(sys.argv[1]);sys.stdout.buffer.write(cv2.cvtColor(a,cv2.COLOR_BGR2RGBA).tobytes())",
        d + "/input.png",
      ],
      { timeout: 10000, maxBuffer: 2000000 },
    );
    if (r.status !== 0) throw Error("RGBA");
    return new Uint8ClampedArray(r.stdout);
  }),
  bins = images.map((data) =>
    ordinaryBinarize({ data, width: 512, height: 512 }),
  );
const maps = doms.map((d) => new Map(d.dom.glyphs.map((g) => [g.id, g]))),
  boxes = [];
for (const g of maps[0].values()) {
  const h = maps[1].get(g.id);
  if (!h || h.ch !== g.ch || h.rect.x !== g.rect.x || h.rect.y !== g.rect.y)
    throw Error("Identity/position drift");
  if (g.role !== "body" || !g.ch.trim()) continue;
  const ink = [g, h].map((a) => {
    const baseline =
      a.rect.y +
      (a.rect.height - a.fontAscent - a.fontDescent) / 2 +
      a.fontAscent;
    return {
      x0: a.rect.x - a.left - 1,
      x1: a.rect.x + a.right + 1,
      y0: baseline - a.ascent - 1,
      y1: baseline + a.descent + 1,
    };
  });
  boxes.push({
    id: g.id,
    ch: g.ch,
    x0: Math.min(...ink.map((a) => a.x0)),
    x1: Math.max(...ink.map((a) => a.x1)),
    y0: Math.min(...ink.map((a) => a.y0)),
    y1: Math.max(...ink.map((a) => a.y1)),
    role: g.role,
  });
}
const sample = (img, x, y) => +(img[(y * 512 + x) * 4] < 128),
  coords = [];
for (let y = 0; y < 37; y++)
  for (let x = 0; x < 37; x++)
    coords.push({
      x,
      y,
      px: Math.floor(64 + (x + 0.5) * 6.5),
      py: Math.floor(64 + (y + 0.5) * 6.5),
    });
const locked = new Set(),
  unknown = [],
  overlaps = [];
for (const a of coords) {
  a.owners = boxes
    .filter(
      (b) =>
        a.px + 1 >= b.x0 && a.px <= b.x1 && a.py + 1 >= b.y0 && a.py <= b.y1,
    )
    .map((b) => b.id);
  a.states = images.map((img) => sample(img, a.px, a.py));
  if (a.owners.length > 1) {
    a.owners.forEach((g) => locked.add(g));
    overlaps.push({ x: a.x, y: a.y, owners: a.owners });
  }
  if (a.states[0] !== a.states[1] && !a.owners.length) unknown.push(a);
}
if (unknown.length) {
  await json(out + "/ownership-failure.json", {
    unknown,
    boxes,
    overlaps,
    locked: [...locked],
  });
  throw Error("Changed pixel with no glyph owner");
}
const samples = coords.map((a) => ({
    x: a.x,
    y: a.y,
    base: a.states[0],
    ...(a.states[0] !== a.states[1] &&
    a.owners.length === 1 &&
    !locked.has(a.owners[0])
      ? { toggle: true, group: a.owners[0] }
      : {}),
  })),
  groups = [
    ...new Set(samples.filter((a) => a.toggle).map((a) => a.group)),
  ].map((id) => {
    const g = maps[0].get(id);
    return {
      id,
      paragraph: +id.split("-")[1],
      codePointIndex: +id.split("-")[2],
      character: g.ch,
      state0: "Native Menlo-Regular white text at frozen12/17px position",
      state1: "Native Menlo-Bold white text at same frozen12/17px position",
    };
  });
const quietSamples = [],
  adaptive = {
    bundleHash,
    classification:
      "Source-scale adaptive binarizer diagnostics only, no mixed-state independence or ordinary decode claim",
    samples: coords.map((a) => ({
      x: a.x,
      y: a.y,
      rawGrayStates: a.states,
      adaptiveStates: bins.map((b) => +b.get(a.px, a.py)),
    })),
  };
for (let y = -4; y < 41; y++)
  for (let x = -4; x < 41; x++)
    if (x < 0 || y < 0 || x >= 37 || y >= 37) {
      const px = Math.floor(64 + (x + 0.5) * 6.5),
        py = Math.floor(64 + (y + 0.5) * 6.5);
      quietSamples.push({ x, y, base: sample(images[0], px, py) });
    }
const input = {
  schema: "aqrobat.native-module-constraints.v1",
  payload: "https://example.com/",
  version: 5,
  ecc: "H",
  mask: 0,
  padding: "post-terminator-affine",
  complete: true,
  geometry: {
    pitch: 6.5,
    origin: [64, 64],
    samplePolicy:
      "floor frozen module-center coordinates; rawgray128 literal native black QR1",
    polarity: "normal",
    sourceHashes: inputHashes,
  },
  groups,
  samples,
  quietSamples,
  ownership: {
    policy:
      "Pixel support square intersects both measured state ink bounds plus1px; ambiguous owners locked to state0 globally; non-toggling groups remain regular.",
    boxes,
    lockedGroups: [...locked],
    overlaps,
    unknownChangedPixels: unknown.length,
  },
  evidenceBoundary:
    "No payload yet for this newly written V5 source. Native source/mixed capture exactness and ordinary recovery remain separate. Uniform field nominal quiet intrusion retained; alignment-o complete native glyph fixed.",
};
await json(out + "/native-input.json", input);
await json(out + "/adaptive-diagnostic.json", adaptive);
await json(out + "/sampling-summary.json", {
  sourceHashes: inputHashes,
  inputSha256: sha(await readFile(out + "/native-input.json")),
  moduleSamples: samples.length,
  togglingSamples: samples.filter((a) => a.toggle).length,
  activeGlyphGroups: groups.length,
  lockedGlyphGroups: locked.size,
  overlapSamples: overlaps.length,
  quietSamples: quietSamples.length,
  quietBlackSamples: quietSamples.filter((a) => a.base).length,
  grayAdaptiveDisagreementSamples: adaptive.samples.filter((a) =>
    a.rawGrayStates.some((v, i) => v !== a.adaptiveStates[i]),
  ).length,
  captures: 0,
  ordinaryCalls: 0,
  passiveProfiles: 0,
});
console.log(
  JSON.stringify({
    input: out + "/native-input.json",
    groups: groups.length,
    toggles: samples.filter((a) => a.toggle).length,
    quietBlack: quietSamples.filter((a) => a.base).length,
  }),
);
