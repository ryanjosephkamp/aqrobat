(() => {
// Project Nayuki's QR Code generator library (MIT License; LICENSE beside this
// file), https://www.nayuki.io/page/qr-code-generator-library, from
// typescript-javascript/qrcodegen.ts at commit 3c6d0b3cefb4e049dc337e82237c9644399716a8
// of https://github.com/nayuki/QR-Code-generator, compiled to JavaScript with
// TypeScript 5.6.3 (tsc --target ES2020 --module none). Splashery added only
// this header and the export at the end. Loaded only when the QR code toy opens.
/*
 * QR Code generator library (TypeScript)
 *
 * Copyright (c) Project Nayuki. (MIT License)
 * https://www.nayuki.io/page/qr-code-generator-library
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so,
 * subject to the following conditions:
 * - The above copyright notice and this permission notice shall be included in
 *   all copies or substantial portions of the Software.
 * - The Software is provided "as is", without warranty of any kind, express or
 *   implied, including but not limited to the warranties of merchantability,
 *   fitness for a particular purpose and noninfringement. In no event shall the
 *   authors or copyright holders be liable for any claim, damages or other
 *   liability, whether in an action of contract, tort or otherwise, arising from,
 *   out of or in connection with the Software or the use or other dealings in the
 *   Software.
 */
"use strict";
var qrcodegen;
(function (qrcodegen) {
    /*---- QR Code symbol class ----*/
    /*
     * A QR Code symbol, which is a type of two-dimension barcode.
     * Invented by Denso Wave and described in the ISO/IEC 18004 standard.
     * Instances of this class represent an immutable square grid of dark and light cells.
     * The class provides static factory functions to create a QR Code from text or binary data.
     * The class covers the QR Code Model 2 specification, supporting all versions (sizes)
     * from 1 to 40, all 4 error correction levels, and 4 character encoding modes.
     *
     * Ways to create a QR Code object:
     * - High level: Take the payload data and call QrCode.encodeText() or QrCode.encodeBinary().
     * - Mid level: Custom-make the list of segments and call QrCode.encodeSegments().
     * - Low level: Custom-make the array of data codeword bytes (including
     *   segment headers and final padding, excluding error correction codewords),
     *   supply the appropriate version number, and call the QrCode() constructor.
     * (Note that all ways require supplying the desired error correction level.)
     */
    class QrCode {
        /*-- Static factory functions (high level) --*/
        // Returns a QR Code representing the given Unicode text string at the given error correction level.
        // As a conservative upper bound, this function is guaranteed to succeed for strings that have 738 or fewer
        // Unicode code points (not UTF-16 code units) if the low error correction level is used. The smallest possible
        // QR Code version is automatically chosen for the output. The ECC level of the result may be higher than the
        // ecl argument if it can be done without increasing the version.
        static encodeText(text, ecl) {
            const segs = qrcodegen.QrSegment.makeSegments(text);
            return QrCode.encodeSegments(segs, ecl);
        }
        // Returns a QR Code representing the given binary data at the given error correction level.
        // This function always encodes using the binary segment mode, not any text mode. The maximum number of
        // bytes allowed is 2953. The smallest possible QR Code version is automatically chosen for the output.
        // The ECC level of the result may be higher than the ecl argument if it can be done without increasing the version.
        static encodeBinary(data, ecl) {
            const seg = qrcodegen.QrSegment.makeBytes(data);
            return QrCode.encodeSegments([seg], ecl);
        }
        /*-- Static factory functions (mid level) --*/
        // Returns a QR Code representing the given segments with the given encoding parameters.
        // The smallest possible QR Code version within the given range is automatically
        // chosen for the output. Iff boostEcl is true, then the ECC level of the result
        // may be higher than the ecl argument if it can be done without increasing the
        // version. The mask number is either between 0 to 7 (inclusive) to force that
        // mask, or -1 to automatically choose an appropriate mask (which may be slow).
        // This function allows the user to create a custom sequence of segments that switches
        // between modes (such as alphanumeric and byte) to encode text in less space.
        // This is a mid-level API; the high-level API is encodeText() and encodeBinary().
        static encodeSegments(segs, ecl, minVersion = 1, maxVersion = 40, mask = -1, boostEcl = true) {
            if (!(QrCode.MIN_VERSION <= minVersion && minVersion <= maxVersion && maxVersion <= QrCode.MAX_VERSION)
                || mask < -1 || mask > 7)
                throw new RangeError("Invalid value");
            // Find the minimal version number to use
            let version;
            let dataUsedBits;
            for (version = minVersion;; version++) {
                const dataCapacityBits = QrCode.getNumDataCodewords(version, ecl) * 8; // Number of data bits available
                const usedBits = QrSegment.getTotalBits(segs, version);
                if (usedBits <= dataCapacityBits) {
                    dataUsedBits = usedBits;
                    break; // This version number is found to be suitable
                }
                if (version >= maxVersion) // All versions in the range could not fit the given data
                    throw new RangeError("Data too long");
            }
            // Increase the error correction level while the data still fits in the current version number
            for (const newEcl of [QrCode.Ecc.MEDIUM, QrCode.Ecc.QUARTILE, QrCode.Ecc.HIGH]) { // From low to high
                if (boostEcl && dataUsedBits <= QrCode.getNumDataCodewords(version, newEcl) * 8)
                    ecl = newEcl;
            }
            // Concatenate all segments to create the data bit string
            let bb = [];
            for (const seg of segs) {
                appendBits(seg.mode.modeBits, 4, bb);
                appendBits(seg.numChars, seg.mode.numCharCountBits(version), bb);
                for (const b of seg.getData())
                    bb.push(b);
            }
            assert(bb.length == dataUsedBits);
            // Add terminator and pad up to a byte if applicable
            const dataCapacityBits = QrCode.getNumDataCodewords(version, ecl) * 8;
            assert(bb.length <= dataCapacityBits);
            appendBits(0, Math.min(4, dataCapacityBits - bb.length), bb);
            appendBits(0, (8 - bb.length % 8) % 8, bb);
            assert(bb.length % 8 == 0);
            // Pad with alternating bytes until data capacity is reached
            for (let padByte = 0xEC; bb.length < dataCapacityBits; padByte ^= 0xEC ^ 0x11)
                appendBits(padByte, 8, bb);
            // Pack bits into bytes in big endian
            let dataCodewords = [];
            while (dataCodewords.length * 8 < bb.length)
                dataCodewords.push(0);
            bb.forEach((b, i) => dataCodewords[i >>> 3] |= b << (7 - (i & 7)));
            // Create the QR Code object
            return new QrCode(version, ecl, dataCodewords, mask);
        }
        /*-- Constructor (low level) and fields --*/
        // Creates a new QR Code with the given version number,
        // error correction level, data codeword bytes, and mask number.
        // This is a low-level API that most users should not use directly.
        // A mid-level API is the encodeSegments() function.
        constructor(
        // The version number of this QR Code, which is between 1 and 40 (inclusive).
        // This determines the size of this barcode.
        version,
        // The error correction level used in this QR Code.
        errorCorrectionLevel, dataCodewords, msk) {
            this.version = version;
            this.errorCorrectionLevel = errorCorrectionLevel;
            // The modules of this QR Code (false = light, true = dark).
            // Immutable after constructor finishes. Accessed through getModule().
            this.modules = [];
            // Indicates function modules that are not subjected to masking. Discarded when constructor finishes.
            this.isFunction = [];
            // Check scalar arguments
            if (version < QrCode.MIN_VERSION || version > QrCode.MAX_VERSION)
                throw new RangeError("Version value out of range");
            if (msk < -1 || msk > 7)
                throw new RangeError("Mask value out of range");
            this.size = version * 4 + 17;
            // Initialize both grids to be size*size arrays of Boolean false
            let row = [];
            for (let i = 0; i < this.size; i++)
                row.push(false);
            for (let i = 0; i < this.size; i++) {
                this.modules.push(row.slice()); // Initially all light
                this.isFunction.push(row.slice());
            }
            // Compute ECC, draw modules
            this.drawFunctionPatterns();
            const allCodewords = this.addEccAndInterleave(dataCodewords);
            this.drawCodewords(allCodewords);
            // Do masking
            if (msk == -1) { // Automatically choose best mask
                let minPenalty = 1000000000;
                for (let i = 0; i < 8; i++) {
                    this.applyMask(i);
                    this.drawFormatBits(i);
                    const penalty = this.getPenaltyScore();
                    if (penalty < minPenalty) {
                        msk = i;
                        minPenalty = penalty;
                    }
                    this.applyMask(i); // Undoes the mask due to XOR
                }
            }
            assert(0 <= msk && msk <= 7);
            this.mask = msk;
            this.applyMask(msk); // Apply the final choice of mask
            this.drawFormatBits(msk); // Overwrite old format bits
            this.isFunction = [];
        }
        /*-- Accessor methods --*/
        // Returns the color of the module (pixel) at the given coordinates, which is false
        // for light or true for dark. The top left corner has the coordinates (x=0, y=0).
        // If the given coordinates are out of bounds, then false (light) is returned.
        getModule(x, y) {
            return 0 <= x && x < this.size && 0 <= y && y < this.size && this.modules[y][x];
        }
        /*-- Private helper methods for constructor: Drawing function modules --*/
        // Reads this object's version field, and draws and marks all function modules.
        drawFunctionPatterns() {
            // Draw horizontal and vertical timing patterns
            for (let i = 0; i < this.size; i++) {
                this.setFunctionModule(6, i, i % 2 == 0);
                this.setFunctionModule(i, 6, i % 2 == 0);
            }
            // Draw 3 finder patterns (all corners except bottom right; overwrites some timing modules)
            this.drawFinderPattern(3, 3);
            this.drawFinderPattern(this.size - 4, 3);
            this.drawFinderPattern(3, this.size - 4);
            // Draw numerous alignment patterns
            const alignPatPos = this.getAlignmentPatternPositions();
            const numAlign = alignPatPos.length;
            for (let i = 0; i < numAlign; i++) {
                for (let j = 0; j < numAlign; j++) {
                    // Don't draw on the three finder corners
                    if (!(i == 0 && j == 0 || i == 0 && j == numAlign - 1 || i == numAlign - 1 && j == 0))
                        this.drawAlignmentPattern(alignPatPos[i], alignPatPos[j]);
                }
            }
            // Draw configuration data
            this.drawFormatBits(0); // Dummy mask value; overwritten later in the constructor
            this.drawVersion();
        }
        // Draws two copies of the format bits (with its own error correction code)
        // based on the given mask and this object's error correction level field.
        drawFormatBits(mask) {
            // Calculate error correction code and pack bits
            const data = this.errorCorrectionLevel.formatBits << 3 | mask; // errCorrLvl is uint2, mask is uint3
            let rem = data;
            for (let i = 0; i < 10; i++)
                rem = (rem << 1) ^ ((rem >>> 9) * 0x537);
            const bits = (data << 10 | rem) ^ 0x5412; // uint15
            assert(bits >>> 15 == 0);
            // Draw first copy
            for (let i = 0; i <= 5; i++)
                this.setFunctionModule(8, i, getBit(bits, i));
            this.setFunctionModule(8, 7, getBit(bits, 6));
            this.setFunctionModule(8, 8, getBit(bits, 7));
            this.setFunctionModule(7, 8, getBit(bits, 8));
            for (let i = 9; i < 15; i++)
                this.setFunctionModule(14 - i, 8, getBit(bits, i));
            // Draw second copy
            for (let i = 0; i < 8; i++)
                this.setFunctionModule(this.size - 1 - i, 8, getBit(bits, i));
            for (let i = 8; i < 15; i++)
                this.setFunctionModule(8, this.size - 15 + i, getBit(bits, i));
            this.setFunctionModule(8, this.size - 8, true); // Always dark
        }
        // Draws two copies of the version bits (with its own error correction code),
        // based on this object's version field, iff 7 <= version <= 40.
        drawVersion() {
            if (this.version < 7)
                return;
            // Calculate error correction code and pack bits
            let rem = this.version; // version is uint6, in the range [7, 40]
            for (let i = 0; i < 12; i++)
                rem = (rem << 1) ^ ((rem >>> 11) * 0x1F25);
            const bits = this.version << 12 | rem; // uint18
            assert(bits >>> 18 == 0);
            // Draw two copies
            for (let i = 0; i < 18; i++) {
                const color = getBit(bits, i);
                const a = this.size - 11 + i % 3;
                const b = Math.floor(i / 3);
                this.setFunctionModule(a, b, color);
                this.setFunctionModule(b, a, color);
            }
        }
        // Draws a 9*9 finder pattern including the border separator,
        // with the center module at (x, y). Modules can be out of bounds.
        drawFinderPattern(x, y) {
            for (let dy = -4; dy <= 4; dy++) {
                for (let dx = -4; dx <= 4; dx++) {
                    const dist = Math.max(Math.abs(dx), Math.abs(dy)); // Chebyshev/infinity norm
                    const xx = x + dx;
                    const yy = y + dy;
                    if (0 <= xx && xx < this.size && 0 <= yy && yy < this.size)
                        this.setFunctionModule(xx, yy, dist != 2 && dist != 4);
                }
            }
        }
        // Draws a 5*5 alignment pattern, with the center module
        // at (x, y). All modules must be in bounds.
        drawAlignmentPattern(x, y) {
            for (let dy = -2; dy <= 2; dy++) {
                for (let dx = -2; dx <= 2; dx++)
                    this.setFunctionModule(x + dx, y + dy, Math.max(Math.abs(dx), Math.abs(dy)) != 1);
            }
        }
        // Sets the color of a module and marks it as a function module.
        // Only used by the constructor. Coordinates must be in bounds.
        setFunctionModule(x, y, isDark) {
            this.modules[y][x] = isDark;
            this.isFunction[y][x] = true;
        }
        /*-- Private helper methods for constructor: Codewords and masking --*/
        // Returns a new byte string representing the given data with the appropriate error correction
        // codewords appended to it, based on this object's version and error correction level.
        addEccAndInterleave(data) {
            const ver = this.version;
            const ecl = this.errorCorrectionLevel;
            if (data.length != QrCode.getNumDataCodewords(ver, ecl))
                throw new RangeError("Invalid argument");
            // Calculate parameter numbers
            const numBlocks = QrCode.NUM_ERROR_CORRECTION_BLOCKS[ecl.ordinal][ver];
            const blockEccLen = QrCode.ECC_CODEWORDS_PER_BLOCK[ecl.ordinal][ver];
            const rawCodewords = Math.floor(QrCode.getNumRawDataModules(ver) / 8);
            const numShortBlocks = numBlocks - rawCodewords % numBlocks;
            const shortBlockLen = Math.floor(rawCodewords / numBlocks);
            // Split data into blocks and append ECC to each block
            let blocks = [];
            const rsDiv = QrCode.reedSolomonComputeDivisor(blockEccLen);
            for (let i = 0, k = 0; i < numBlocks; i++) {
                let dat = data.slice(k, k + shortBlockLen - blockEccLen + (i < numShortBlocks ? 0 : 1));
                k += dat.length;
                const ecc = QrCode.reedSolomonComputeRemainder(dat, rsDiv);
                if (i < numShortBlocks)
                    dat.push(0);
                blocks.push(dat.concat(ecc));
            }
            // Interleave (not concatenate) the bytes from every block into a single sequence
            let result = [];
            for (let i = 0; i < blocks[0].length; i++) {
                blocks.forEach((block, j) => {
                    // Skip the padding byte in short blocks
                    if (i != shortBlockLen - blockEccLen || j >= numShortBlocks)
                        result.push(block[i]);
                });
            }
            assert(result.length == rawCodewords);
            return result;
        }
        // Draws the given sequence of 8-bit codewords (data and error correction) onto the entire
        // data area of this QR Code. Function modules need to be marked off before this is called.
        drawCodewords(data) {
            if (data.length != Math.floor(QrCode.getNumRawDataModules(this.version) / 8))
                throw new RangeError("Invalid argument");
            let i = 0; // Bit index into the data
            // Do the funny zigzag scan
            for (let right = this.size - 1; right >= 1; right -= 2) { // Index of right column in each column pair
                if (right == 6)
                    right = 5;
                for (let vert = 0; vert < this.size; vert++) { // Vertical counter
                    for (let j = 0; j < 2; j++) {
                        const x = right - j; // Actual x coordinate
                        const upward = ((right + 1) & 2) == 0;
                        const y = upward ? this.size - 1 - vert : vert; // Actual y coordinate
                        if (!this.isFunction[y][x] && i < data.length * 8) {
                            this.modules[y][x] = getBit(data[i >>> 3], 7 - (i & 7));
                            i++;
                        }
                        // If this QR Code has any remainder bits (0 to 7), they were assigned as
                        // 0/false/light by the constructor and are left unchanged by this method
                    }
                }
            }
            assert(i == data.length * 8);
        }
        // XORs the codeword modules in this QR Code with the given mask pattern.
        // The function modules must be marked and the codeword bits must be drawn
        // before masking. Due to the arithmetic of XOR, calling applyMask() with
        // the same mask value a second time will undo the mask. A final well-formed
        // QR Code needs exactly one (not zero, two, etc.) mask applied.
        applyMask(mask) {
            if (mask < 0 || mask > 7)
                throw new RangeError("Mask value out of range");
            for (let y = 0; y < this.size; y++) {
                for (let x = 0; x < this.size; x++) {
                    let invert;
                    switch (mask) {
                        case 0:
                            invert = (x + y) % 2 == 0;
                            break;
                        case 1:
                            invert = y % 2 == 0;
                            break;
                        case 2:
                            invert = x % 3 == 0;
                            break;
                        case 3:
                            invert = (x + y) % 3 == 0;
                            break;
                        case 4:
                            invert = (Math.floor(x / 3) + Math.floor(y / 2)) % 2 == 0;
                            break;
                        case 5:
                            invert = x * y % 2 + x * y % 3 == 0;
                            break;
                        case 6:
                            invert = (x * y % 2 + x * y % 3) % 2 == 0;
                            break;
                        case 7:
                            invert = ((x + y) % 2 + x * y % 3) % 2 == 0;
                            break;
                        default: throw new Error("Unreachable");
                    }
                    if (!this.isFunction[y][x] && invert)
                        this.modules[y][x] = !this.modules[y][x];
                }
            }
        }
        // Calculates and returns the penalty score based on state of this QR Code's current modules.
        // This is used by the automatic mask choice algorithm to find the mask pattern that yields the lowest score.
        getPenaltyScore() {
            let result = 0;
            // Adjacent modules in row having same color, and finder-like patterns
            for (let y = 0; y < this.size; y++) {
                let runColor = false;
                let runX = 0;
                let runHistory = [0, 0, 0, 0, 0, 0, 0];
                for (let x = 0; x < this.size; x++) {
                    if (this.modules[y][x] == runColor) {
                        runX++;
                        if (runX == 5)
                            result += QrCode.PENALTY_N1;
                        else if (runX > 5)
                            result++;
                    }
                    else {
                        this.finderPenaltyAddHistory(runX, runHistory);
                        if (!runColor)
                            result += this.finderPenaltyCountPatterns(runHistory) * QrCode.PENALTY_N3;
                        runColor = this.modules[y][x];
                        runX = 1;
                    }
                }
                result += this.finderPenaltyTerminateAndCount(runColor, runX, runHistory) * QrCode.PENALTY_N3;
            }
            // Adjacent modules in column having same color, and finder-like patterns
            for (let x = 0; x < this.size; x++) {
                let runColor = false;
                let runY = 0;
                let runHistory = [0, 0, 0, 0, 0, 0, 0];
                for (let y = 0; y < this.size; y++) {
                    if (this.modules[y][x] == runColor) {
                        runY++;
                        if (runY == 5)
                            result += QrCode.PENALTY_N1;
                        else if (runY > 5)
                            result++;
                    }
                    else {
                        this.finderPenaltyAddHistory(runY, runHistory);
                        if (!runColor)
                            result += this.finderPenaltyCountPatterns(runHistory) * QrCode.PENALTY_N3;
                        runColor = this.modules[y][x];
                        runY = 1;
                    }
                }
                result += this.finderPenaltyTerminateAndCount(runColor, runY, runHistory) * QrCode.PENALTY_N3;
            }
            // 2*2 blocks of modules having same color
            for (let y = 0; y < this.size - 1; y++) {
                for (let x = 0; x < this.size - 1; x++) {
                    const color = this.modules[y][x];
                    if (color == this.modules[y][x + 1] &&
                        color == this.modules[y + 1][x] &&
                        color == this.modules[y + 1][x + 1])
                        result += QrCode.PENALTY_N2;
                }
            }
            // Balance of dark and light modules
            let dark = 0;
            for (const row of this.modules)
                dark = row.reduce((sum, color) => sum + (color ? 1 : 0), dark);
            const total = this.size * this.size; // Note that size is odd, so dark/total != 1/2
            // Compute the smallest integer k >= 0 such that (45-5k)% <= dark/total <= (55+5k)%
            const k = Math.ceil(Math.abs(dark * 20 - total * 10) / total) - 1;
            assert(0 <= k && k <= 9);
            result += k * QrCode.PENALTY_N4;
            assert(0 <= result && result <= 2568888); // Non-tight upper bound based on default values of PENALTY_N1, ..., N4
            return result;
        }
        /*-- Private helper functions --*/
        // Returns an ascending list of positions of alignment patterns for this version number.
        // Each position is in the range [0,177), and are used on both the x and y axes.
        // This could be implemented as lookup table of 40 variable-length lists of integers.
        getAlignmentPatternPositions() {
            if (this.version == 1)
                return [];
            else {
                const numAlign = Math.floor(this.version / 7) + 2;
                const step = Math.floor((this.version * 8 + numAlign * 3 + 5) / (numAlign * 4 - 4)) * 2;
                let result = [6];
                for (let pos = this.size - 7; result.length < numAlign; pos -= step)
                    result.splice(1, 0, pos);
                return result;
            }
        }
        // Returns the number of data bits that can be stored in a QR Code of the given version number, after
        // all function modules are excluded. This includes remainder bits, so it might not be a multiple of 8.
        // The result is in the range [208, 29648]. This could be implemented as a 40-entry lookup table.
        static getNumRawDataModules(ver) {
            if (ver < QrCode.MIN_VERSION || ver > QrCode.MAX_VERSION)
                throw new RangeError("Version number out of range");
            let result = (16 * ver + 128) * ver + 64;
            if (ver >= 2) {
                const numAlign = Math.floor(ver / 7) + 2;
                result -= (25 * numAlign - 10) * numAlign - 55;
                if (ver >= 7)
                    result -= 36;
            }
            assert(208 <= result && result <= 29648);
            return result;
        }
        // Returns the number of 8-bit data (i.e. not error correction) codewords contained in any
        // QR Code of the given version number and error correction level, with remainder bits discarded.
        // This stateless pure function could be implemented as a (40*4)-cell lookup table.
        static getNumDataCodewords(ver, ecl) {
            return Math.floor(QrCode.getNumRawDataModules(ver) / 8) -
                QrCode.ECC_CODEWORDS_PER_BLOCK[ecl.ordinal][ver] *
                    QrCode.NUM_ERROR_CORRECTION_BLOCKS[ecl.ordinal][ver];
        }
        // Returns a Reed-Solomon ECC generator polynomial for the given degree. This could be
        // implemented as a lookup table over all possible parameter values, instead of as an algorithm.
        static reedSolomonComputeDivisor(degree) {
            if (degree < 1 || degree > 255)
                throw new RangeError("Degree out of range");
            // Polynomial coefficients are stored from highest to lowest power, excluding the leading term which is always 1.
            // For example the polynomial x^3 + 255x^2 + 8x + 93 is stored as the uint8 array [255, 8, 93].
            let result = [];
            for (let i = 0; i < degree - 1; i++)
                result.push(0);
            result.push(1); // Start off with the monomial x^0
            // Compute the product polynomial (x - r^0) * (x - r^1) * (x - r^2) * ... * (x - r^{degree-1}),
            // and drop the highest monomial term which is always 1x^degree.
            // Note that r = 0x02, which is a generator element of this field GF(2^8/0x11D).
            let root = 1;
            for (let i = 0; i < degree; i++) {
                // Multiply the current product by (x - r^i)
                for (let j = 0; j < result.length; j++) {
                    result[j] = QrCode.reedSolomonMultiply(result[j], root);
                    if (j + 1 < result.length)
                        result[j] ^= result[j + 1];
                }
                root = QrCode.reedSolomonMultiply(root, 0x02);
            }
            return result;
        }
        // Returns the Reed-Solomon error correction codeword for the given data and divisor polynomials.
        static reedSolomonComputeRemainder(data, divisor) {
            let result = divisor.map(_ => 0);
            for (const b of data) { // Polynomial division
                const factor = b ^ result.shift();
                result.push(0);
                divisor.forEach((coef, i) => result[i] ^= QrCode.reedSolomonMultiply(coef, factor));
            }
            return result;
        }
        // Returns the product of the two given field elements modulo GF(2^8/0x11D). The arguments and result
        // are unsigned 8-bit integers. This could be implemented as a lookup table of 256*256 entries of uint8.
        static reedSolomonMultiply(x, y) {
            if (x >>> 8 != 0 || y >>> 8 != 0)
                throw new RangeError("Byte out of range");
            // Russian peasant multiplication
            let z = 0;
            for (let i = 7; i >= 0; i--) {
                z = (z << 1) ^ ((z >>> 7) * 0x11D);
                z ^= ((y >>> i) & 1) * x;
            }
            assert(z >>> 8 == 0);
            return z;
        }
        // Can only be called immediately after a light run is added, and
        // returns either 0, 1, or 2. A helper function for getPenaltyScore().
        finderPenaltyCountPatterns(runHistory) {
            const n = runHistory[1];
            assert(n <= this.size * 3);
            const core = n > 0 && runHistory[2] == n && runHistory[3] == n * 3 && runHistory[4] == n && runHistory[5] == n;
            return (core && runHistory[0] >= n * 4 && runHistory[6] >= n ? 1 : 0)
                + (core && runHistory[6] >= n * 4 && runHistory[0] >= n ? 1 : 0);
        }
        // Must be called at the end of a line (row or column) of modules. A helper function for getPenaltyScore().
        finderPenaltyTerminateAndCount(currentRunColor, currentRunLength, runHistory) {
            if (currentRunColor) { // Terminate dark run
                this.finderPenaltyAddHistory(currentRunLength, runHistory);
                currentRunLength = 0;
            }
            currentRunLength += this.size; // Add light border to final run
            this.finderPenaltyAddHistory(currentRunLength, runHistory);
            return this.finderPenaltyCountPatterns(runHistory);
        }
        // Pushes the given value to the front and drops the last value. A helper function for getPenaltyScore().
        finderPenaltyAddHistory(currentRunLength, runHistory) {
            if (runHistory[0] == 0)
                currentRunLength += this.size; // Add light border to initial run
            runHistory.pop();
            runHistory.unshift(currentRunLength);
        }
    }
    /*-- Constants and tables --*/
    // The minimum version number supported in the QR Code Model 2 standard.
    QrCode.MIN_VERSION = 1;
    // The maximum version number supported in the QR Code Model 2 standard.
    QrCode.MAX_VERSION = 40;
    // For use in getPenaltyScore(), when evaluating which mask is best.
    QrCode.PENALTY_N1 = 3;
    QrCode.PENALTY_N2 = 3;
    QrCode.PENALTY_N3 = 40;
    QrCode.PENALTY_N4 = 10;
    QrCode.ECC_CODEWORDS_PER_BLOCK = [
        // Version: (note that index 0 is for padding, and is set to an illegal value)
        //0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40    Error correction level
        [-1, 7, 10, 15, 20, 26, 18, 20, 24, 30, 18, 20, 24, 26, 30, 22, 24, 28, 30, 28, 28, 28, 28, 30, 30, 26, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30], // Low
        [-1, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24, 28, 28, 26, 26, 26, 26, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28], // Medium
        [-1, 13, 22, 18, 26, 18, 24, 18, 22, 20, 24, 28, 26, 24, 20, 30, 24, 28, 28, 26, 30, 28, 30, 30, 30, 30, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30], // Quartile
        [-1, 17, 28, 22, 16, 22, 28, 26, 26, 24, 28, 24, 28, 22, 24, 24, 30, 28, 28, 26, 28, 30, 24, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30], // High
    ];
    QrCode.NUM_ERROR_CORRECTION_BLOCKS = [
        // Version: (note that index 0 is for padding, and is set to an illegal value)
        //0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40    Error correction level
        [-1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 4, 4, 4, 4, 4, 6, 6, 6, 6, 7, 8, 8, 9, 9, 10, 12, 12, 12, 13, 14, 15, 16, 17, 18, 19, 19, 20, 21, 22, 24, 25], // Low
        [-1, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 8, 9, 9, 10, 10, 11, 13, 14, 16, 17, 17, 18, 20, 21, 23, 25, 26, 28, 29, 31, 33, 35, 37, 38, 40, 43, 45, 47, 49], // Medium
        [-1, 1, 1, 2, 2, 4, 4, 6, 6, 8, 8, 8, 10, 12, 16, 12, 17, 16, 18, 21, 20, 23, 23, 25, 27, 29, 34, 34, 35, 38, 40, 43, 45, 48, 51, 53, 56, 59, 62, 65, 68], // Quartile
        [-1, 1, 1, 2, 4, 4, 4, 5, 6, 8, 8, 11, 11, 16, 16, 18, 16, 19, 21, 25, 25, 25, 34, 30, 32, 35, 37, 40, 42, 45, 48, 51, 54, 57, 60, 63, 66, 70, 74, 77, 81], // High
    ];
    qrcodegen.QrCode = QrCode;
    // Appends the given number of low-order bits of the given value
    // to the given buffer. Requires 0 <= len <= 31 and 0 <= val < 2^len.
    function appendBits(val, len, bb) {
        if (len < 0 || len > 31 || val >>> len != 0)
            throw new RangeError("Value out of range");
        for (let i = len - 1; i >= 0; i--) // Append bit by bit
            bb.push((val >>> i) & 1);
    }
    // Returns true iff the i'th bit of x is set to 1.
    function getBit(x, i) {
        return ((x >>> i) & 1) != 0;
    }
    // Throws an exception if the given condition is false.
    function assert(cond) {
        if (!cond)
            throw new Error("Assertion error");
    }
    /*---- Data segment class ----*/
    /*
     * A segment of character/binary/control data in a QR Code symbol.
     * Instances of this class are immutable.
     * The mid-level way to create a segment is to take the payload data
     * and call a static factory function such as QrSegment.makeNumeric().
     * The low-level way to create a segment is to custom-make the bit buffer
     * and call the QrSegment() constructor with appropriate values.
     * This segment class imposes no length restrictions, but QR Codes have restrictions.
     * Even in the most favorable conditions, a QR Code can only hold 7089 characters of data.
     * Any segment longer than this is meaningless for the purpose of generating QR Codes.
     */
    class QrSegment {
        /*-- Static factory functions (mid level) --*/
        // Returns a segment representing the given binary data encoded in
        // byte mode. All input byte arrays are acceptable. Any text string
        // can be converted to UTF-8 bytes and encoded as a byte mode segment.
        static makeBytes(data) {
            let bb = [];
            for (const b of data)
                appendBits(b, 8, bb);
            return new QrSegment(QrSegment.Mode.BYTE, data.length, bb);
        }
        // Returns a segment representing the given string of decimal digits encoded in numeric mode.
        static makeNumeric(digits) {
            if (!QrSegment.isNumeric(digits))
                throw new RangeError("String contains non-numeric characters");
            let bb = [];
            for (let i = 0; i < digits.length;) { // Consume up to 3 digits per iteration
                const n = Math.min(digits.length - i, 3);
                appendBits(parseInt(digits.substring(i, i + n), 10), n * 3 + 1, bb);
                i += n;
            }
            return new QrSegment(QrSegment.Mode.NUMERIC, digits.length, bb);
        }
        // Returns a segment representing the given text string encoded in alphanumeric mode.
        // The characters allowed are: 0 to 9, A to Z (uppercase only), space,
        // dollar, percent, asterisk, plus, hyphen, period, slash, colon.
        static makeAlphanumeric(text) {
            if (!QrSegment.isAlphanumeric(text))
                throw new RangeError("String contains unencodable characters in alphanumeric mode");
            let bb = [];
            let i;
            for (i = 0; i + 2 <= text.length; i += 2) { // Process groups of 2
                let temp = QrSegment.ALPHANUMERIC_CHARSET.indexOf(text.charAt(i)) * 45;
                temp += QrSegment.ALPHANUMERIC_CHARSET.indexOf(text.charAt(i + 1));
                appendBits(temp, 11, bb);
            }
            if (i < text.length) // 1 character remaining
                appendBits(QrSegment.ALPHANUMERIC_CHARSET.indexOf(text.charAt(i)), 6, bb);
            return new QrSegment(QrSegment.Mode.ALPHANUMERIC, text.length, bb);
        }
        // Returns a new mutable list of zero or more segments to represent the given Unicode text string.
        // The result may use various segment modes and switch modes to optimize the length of the bit stream.
        static makeSegments(text) {
            // Select the most efficient segment encoding automatically
            if (text == "")
                return [];
            else if (QrSegment.isNumeric(text))
                return [QrSegment.makeNumeric(text)];
            else if (QrSegment.isAlphanumeric(text))
                return [QrSegment.makeAlphanumeric(text)];
            else
                return [QrSegment.makeBytes(QrSegment.toUtf8ByteArray(text))];
        }
        // Returns a segment representing an Extended Channel Interpretation
        // (ECI) designator with the given assignment value.
        static makeEci(assignVal) {
            let bb = [];
            if (assignVal < 0)
                throw new RangeError("ECI assignment value out of range");
            else if (assignVal < (1 << 7))
                appendBits(assignVal, 8, bb);
            else if (assignVal < (1 << 14)) {
                appendBits(0b10, 2, bb);
                appendBits(assignVal, 14, bb);
            }
            else if (assignVal < 1000000) {
                appendBits(0b110, 3, bb);
                appendBits(assignVal, 21, bb);
            }
            else
                throw new RangeError("ECI assignment value out of range");
            return new QrSegment(QrSegment.Mode.ECI, 0, bb);
        }
        // Tests whether the given string can be encoded as a segment in numeric mode.
        // A string is encodable iff each character is in the range 0 to 9.
        static isNumeric(text) {
            return QrSegment.NUMERIC_REGEX.test(text);
        }
        // Tests whether the given string can be encoded as a segment in alphanumeric mode.
        // A string is encodable iff each character is in the following set: 0 to 9, A to Z
        // (uppercase only), space, dollar, percent, asterisk, plus, hyphen, period, slash, colon.
        static isAlphanumeric(text) {
            return QrSegment.ALPHANUMERIC_REGEX.test(text);
        }
        /*-- Constructor (low level) and fields --*/
        // Creates a new QR Code segment with the given attributes and data.
        // The character count (numChars) must agree with the mode and the bit buffer length,
        // but the constraint isn't checked. The given bit buffer is cloned and stored.
        constructor(
        // The mode indicator of this segment.
        mode,
        // The length of this segment's unencoded data. Measured in characters for
        // numeric/alphanumeric/kanji mode, bytes for byte mode, and 0 for ECI mode.
        // Always zero or positive. Not the same as the data's bit length.
        numChars,
        // The data bits of this segment. Accessed through getData().
        bitData) {
            this.mode = mode;
            this.numChars = numChars;
            this.bitData = bitData;
            if (numChars < 0)
                throw new RangeError("Invalid argument");
            this.bitData = bitData.slice(); // Make defensive copy
        }
        /*-- Methods --*/
        // Returns a new copy of the data bits of this segment.
        getData() {
            return this.bitData.slice(); // Make defensive copy
        }
        // (Package-private) Calculates and returns the number of bits needed to encode the given segments at
        // the given version. The result is infinity if a segment has too many characters to fit its length field.
        static getTotalBits(segs, version) {
            let result = 0;
            for (const seg of segs) {
                const ccbits = seg.mode.numCharCountBits(version);
                if (seg.numChars >= (1 << ccbits))
                    return Infinity; // The segment's length doesn't fit the field's bit width
                result += 4 + ccbits + seg.bitData.length;
            }
            return result;
        }
        // Returns a new array of bytes representing the given string encoded in UTF-8.
        static toUtf8ByteArray(str) {
            str = encodeURI(str);
            let result = [];
            for (let i = 0; i < str.length; i++) {
                if (str.charAt(i) != "%")
                    result.push(str.charCodeAt(i));
                else {
                    result.push(parseInt(str.substring(i + 1, i + 3), 16));
                    i += 2;
                }
            }
            return result;
        }
    }
    /*-- Constants --*/
    // Describes precisely all strings that are encodable in numeric mode.
    QrSegment.NUMERIC_REGEX = /^[0-9]*$/;
    // Describes precisely all strings that are encodable in alphanumeric mode.
    QrSegment.ALPHANUMERIC_REGEX = /^[A-Z0-9 $%*+.\/:-]*$/;
    // The set of all legal characters in alphanumeric mode,
    // where each character value maps to the index in the string.
    QrSegment.ALPHANUMERIC_CHARSET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:";
    qrcodegen.QrSegment = QrSegment;
})(qrcodegen || (qrcodegen = {}));
/*---- Public helper enumeration ----*/
(function (qrcodegen) {
    var QrCode;
    (function (QrCode) {
        /*
         * The error correction level in a QR Code symbol. Immutable.
         */
        class Ecc {
            /*-- Constructor and fields --*/
            constructor(
            // In the range 0 to 3 (unsigned 2-bit integer).
            ordinal,
            // (Package-private) In the range 0 to 3 (unsigned 2-bit integer).
            formatBits) {
                this.ordinal = ordinal;
                this.formatBits = formatBits;
            }
        }
        /*-- Constants --*/
        Ecc.LOW = new Ecc(0, 1); // The QR Code can tolerate about  7% erroneous codewords
        Ecc.MEDIUM = new Ecc(1, 0); // The QR Code can tolerate about 15% erroneous codewords
        Ecc.QUARTILE = new Ecc(2, 3); // The QR Code can tolerate about 25% erroneous codewords
        Ecc.HIGH = new Ecc(3, 2); // The QR Code can tolerate about 30% erroneous codewords
        QrCode.Ecc = Ecc;
    })(QrCode = qrcodegen.QrCode || (qrcodegen.QrCode = {}));
})(qrcodegen || (qrcodegen = {}));
/*---- Public helper enumeration ----*/
(function (qrcodegen) {
    var QrSegment;
    (function (QrSegment) {
        /*
         * Describes how a segment's data bits are interpreted. Immutable.
         */
        class Mode {
            /*-- Constructor and fields --*/
            constructor(
            // The mode indicator bits, which is a uint4 value (range 0 to 15).
            modeBits,
            // Number of character count bits for three different version ranges.
            numBitsCharCount) {
                this.modeBits = modeBits;
                this.numBitsCharCount = numBitsCharCount;
            }
            /*-- Method --*/
            // (Package-private) Returns the bit width of the character count field for a segment in
            // this mode in a QR Code at the given version number. The result is in the range [0, 16].
            numCharCountBits(ver) {
                return this.numBitsCharCount[Math.floor((ver + 7) / 17)];
            }
        }
        /*-- Constants --*/
        Mode.NUMERIC = new Mode(0x1, [10, 12, 14]);
        Mode.ALPHANUMERIC = new Mode(0x2, [9, 11, 13]);
        Mode.BYTE = new Mode(0x4, [8, 16, 16]);
        Mode.KANJI = new Mode(0x8, [8, 10, 12]);
        Mode.ECI = new Mode(0x7, [0, 0, 0]);
        QrSegment.Mode = Mode;
    })(QrSegment = qrcodegen.QrSegment || (qrcodegen.QrSegment = {}));
})(qrcodegen || (qrcodegen = {}));


const LEVELS = {
  L: qrcodegen.QrCode.Ecc.LOW,
  M: qrcodegen.QrCode.Ecc.MEDIUM,
  Q: qrcodegen.QrCode.Ecc.QUARTILE,
  H: qrcodegen.QrCode.Ecc.HIGH,
};
const PRESETS = Object.freeze(
  [
    ["#", "Hash"],
    ["@", "At"],
    ["M", "M"],
    ["█", "Block"],
    [".", "Dots"],
    ["*", "Asterisk"],
    ["+", "Plus"],
    ["●", "Circle"],
    ["■", "Square"],
    ["⚫️", "Black circle"],
    ["◼️", "Black square"],
    ["▪️", "Small square"],
    ["🔳", "Frame"],
    ["🙂", "Face"],
    ["🧍", "Person"],
    ["🐱", "Cat"],
    ["🍇", "Grapes"],
    ["🏁", "Flag"],
  ].map(([glyph, name]) => Object.freeze({ glyph, name })),
);

const DEFAULTS = Object.freeze({
  glyph: "#",
  repeatX: 4,
  repeatY: 2,
  ecc: "M",
  boost: true,
  width: 656,
  font: "Menlo",
  stroke: 0.1,
});
const segmenter = new Intl.Segmenter("en", { granularity: "grapheme" });

function validateGlyph(glyph) {
  if (
    typeof glyph !== "string" ||
    !glyph.isWellFormed() ||
    !glyph.length ||
    new TextEncoder().encode(glyph).length > 64 ||
    [...segmenter.segment(glyph)].length !== 1 ||
    /[\p{White_Space}\p{Cc}\u200b\u200c\u2060\ufeff\u202a-\u202e\u2066-\u2069]/u.test(
      glyph,
    ) ||
    /\p{Cf}/u.test(glyph.replace(/[\u200d\u{e0020}-\u{e007f}]/gu, "")) ||
    !glyph.replace(/[\p{M}\p{Cf}]/gu, "").length
  )
    throw new RangeError(
      "Choose one visible character or emoji (up to 64 UTF-8 bytes).",
    );
  return glyph;
}

/** Exact graphemes, deduplicated in first-seen order; whitespace is a separator. */
function parsePalette(input) {
  if (
    typeof input !== "string" ||
    !input.isWellFormed() ||
    new TextEncoder().encode(input).length > 4096
  )
    throw new RangeError(
      "Use a well-formed symbol palette up to 4096 UTF-8 bytes.",
    );
  const symbols = [
    ...segmenter.segment(input.replace(/\p{White_Space}/gu, "")),
  ].map(({ segment }) => validateGlyph(segment));
  const palette = [...new Set(symbols)];
  if (!palette.length)
    throw new RangeError("Enter at least one visible symbol or emoji.");
  return palette;
}

function normalizeOptions(options = {}) {
  if (!options || typeof options !== "object" || Array.isArray(options))
    throw new TypeError("Expected an options object.");
  const known = Object.keys(DEFAULTS);
  for (const key of Object.keys(options))
    if (!known.includes(key)) throw new RangeError(`Unknown option: ${key}`);
  const o = { ...DEFAULTS, ...options };
  parsePalette(o.glyph);
  if (!Object.hasOwn(LEVELS, o.ecc))
    throw new RangeError("Choose L, M, Q, or H error correction.");
  if (typeof o.boost !== "boolean")
    throw new TypeError("boost must be a boolean.");
  if (
    !Number.isInteger(o.repeatX) ||
    !Number.isInteger(o.repeatY) ||
    o.repeatX < 1 ||
    o.repeatX > 4 ||
    o.repeatY < 1 ||
    o.repeatY > 4
  )
    throw new RangeError("Use 1–4 characters across and 1–4 rows per module.");
  if (!Number.isInteger(o.width) || o.width < 200 || o.width > 1536)
    throw new RangeError("Use an integer size from 200 to 1536 pixels.");
  if (!["Menlo", "Courier New", "monospace"].includes(o.font))
    throw new RangeError("Choose Menlo, Courier New, or system monospace.");
  if (![0, 0.1].includes(o.stroke))
    throw new RangeError("Use 0 or 0.1 for stroke.");
  return o;
}

/** Build a standard matrix, then replace dark modules with actual characters. */
function generate(payload, options = {}) {
  if (typeof payload !== "string" || !payload.length || !payload.isWellFormed())
    throw new TypeError("Enter nonempty, well-formed text.");
  const bytes = new TextEncoder().encode(payload);
  if (bytes.length > 1024)
    throw new RangeError(
      "Use at most 1024 UTF-8 bytes; input is never truncated.",
    );
  const o = normalizeOptions(options);
  const unicode = /[^\x00-\x7f]/.test(payload);
  const segments = unicode
    ? [
        qrcodegen.QrSegment.makeEci(26),
        qrcodegen.QrSegment.makeBytes(Array.from(bytes)),
      ]
    : qrcodegen.QrSegment.makeSegments(payload);
  const code = qrcodegen.QrCode.encodeSegments(
    segments,
    LEVELS[o.ecc],
    1,
    40,
    -1,
    o.boost,
  );
  const matrix = Array.from({ length: code.size }, (_, y) =>
    Array.from({ length: code.size }, (_, x) => code.getModule(x, y)),
  );
  const palette = parsePalette(o.glyph);
  let next = 0;
  const glyphMatrix = matrix.map((row) =>
    row.map((dark) => (dark ? palette[next++ % palette.length] : null)),
  );
  const quiet = 4,
    totalModules = code.size + quiet * 2;
  const rows = [];
  for (let y = -quiet; y < code.size + quiet; y++) {
    let row = "";
    for (let x = -quiet; x < code.size + quiet; x++)
      row += (glyphMatrix[y]?.[x] ?? " ").repeat(o.repeatX);
    for (let i = 0; i < o.repeatY; i++) rows.push(row);
  }
  const recipe = { schema: "aqrobat-recipe-v2", payload, options: o };
  return {
    recipe,
    matrix,
    palette,
    glyphMatrix,
    rows,
    text: rows.join("\n") + "\n",
    quiet,
    totalModules,
    modules: code.size,
    version: code.version,
    utf8Bytes: bytes.length,
    eci: unicode ? 26 : null,
    requestedEcc: o.ecc,
    actualEcc: ["L", "M", "Q", "H"][code.errorCorrectionLevel.ordinal],
    characterColumns: totalModules * o.repeatX,
    characterRows: rows.length,
    scanStatus: "untested",
  };
}

function fromRecipe(value) {
  if (
    !value ||
    !["aqrobat-recipe-v1", "aqrobat-recipe-v2"].includes(value.schema) ||
    typeof value.payload !== "string" ||
    !value.options
  )
    throw new TypeError("Expected an Aqrobat v1 or v2 recipe.");
  if (value.schema === "aqrobat-recipe-v1")
    validateGlyph({ ...DEFAULTS, ...value.options }.glyph);
  const qr = generate(value.payload, value.options);
  qr.recipe.schema = value.schema;
  return qr;
}

function recipeKey(recipe) {
  const qr = fromRecipe(recipe);
  return JSON.stringify(qr.recipe);
}

function escapeXml(value) {
  return String(value).replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ],
  );
}

/** Font-dependent glyph SVG. No dark module rectangles or hidden solid QR. */
function toSvg(qr) {
  const o = qr.recipe.options;
  const cw = o.width / qr.characterColumns,
    ch = o.width / qr.characterRows;
  const fs = Math.min(cw / 0.6, ch) * 0.95;
  const font =
    o.font === "monospace" ? "monospace" : `&quot;${o.font}&quot;,monospace`;
  const nodes = [];
  qr.matrix.forEach((row, y) =>
    row.forEach((dark, x) => {
      if (!dark) return;
      for (let dy = 0; dy < o.repeatY; dy++)
        for (let dx = 0; dx < o.repeatX; dx++)
          nodes.push(
            `<text x="${((x + qr.quiet) * o.repeatX + dx + 0.5) * cw}" y="${((y + qr.quiet) * o.repeatY + dy + 0.5) * ch}">${escapeXml(qr.glyphMatrix[y][x])}</text>`,
          );
    }),
  );
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${o.width}" height="${o.width}" viewBox="0 0 ${o.width} ${o.width}" role="img" aria-label="Experimental glyph QR"><rect width="100%" height="100%" fill="white"/><g fill="black" stroke="black" stroke-width="${fs * o.stroke}" paint-order="stroke fill" font-family="${font}" font-size="${fs}" font-weight="700" text-anchor="middle" dominant-baseline="central">${nodes.join("")}</g></svg>\n`;
}

const rowGlyph = (glyph) => /^[\x21-\x7e█]$/.test(glyph);
const fontFamily = (font) =>
  font === "monospace"
    ? "monospace"
    : `"${font}", "Apple Color Emoji", "Segoe UI Emoji", "Noto Color Emoji", monospace`;

function render(canvas, qr, width = qr.recipe.options.width) {
  if (!Number.isInteger(width) || width < 1 || width > 1536)
    throw new RangeError("Render size must be an integer from 1 to 1536.");
  canvas.width = canvas.height = width;
  const ctx = canvas.getContext("2d");
  const o = qr.recipe.options,
    family = fontFamily(o.font);
  ctx.fillStyle = "white";
  ctx.fillRect(0, 0, width, width);
  ctx.fillStyle = ctx.strokeStyle = "black";
  ctx.font = `700 100px ${family}`;
  if (qr.palette.every(rowGlyph)) {
    const m = ctx.measureText("M");
    const fontSize = width / ((qr.characterColumns * m.width) / 100);
    const lineHeight = width / qr.characterRows;
    const ascent = (m.fontBoundingBoxAscent ?? m.actualBoundingBoxAscent) / 100;
    const descent =
      (m.fontBoundingBoxDescent ?? m.actualBoundingBoxDescent) / 100;
    const baseline =
      (lineHeight - (ascent + descent) * fontSize) / 2 + ascent * fontSize;
    ctx.font = `700 ${fontSize}px ${family}`;
    ctx.textBaseline = "alphabetic";
    ctx.lineWidth = o.stroke * fontSize;
    qr.rows.forEach((row, i) => {
      if (o.stroke) ctx.strokeText(row, 0, baseline + i * lineHeight);
      ctx.fillText(row, 0, baseline + i * lineHeight);
    });
    return {
      kind: "text rows",
      fontSize,
      lineHeight,
      width,
      characterOnly: true,
    };
  }
  const cw = width / qr.characterColumns,
    ch = width / qr.characterRows;
  const sizes = new Map(
    qr.palette.map((glyph) => {
      const m = ctx.measureText(glyph);
      const height =
        ((m.actualBoundingBoxAscent || 85) +
          (m.actualBoundingBoxDescent || 15)) /
        100;
      return [
        glyph,
        Math.min(cw / ((m.width || 100) / 100), ch / height) * 0.95,
      ];
    }),
  );
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  qr.matrix.forEach((row, y) =>
    row.forEach((dark, x) => {
      if (!dark) return;
      const glyph = qr.glyphMatrix[y][x],
        fontSize = sizes.get(glyph);
      ctx.font = `700 ${fontSize}px ${family}`;
      ctx.lineWidth = o.stroke * fontSize;
      for (let dy = 0; dy < o.repeatY; dy++)
        for (let dx = 0; dx < o.repeatX; dx++) {
          const gx = ((x + qr.quiet) * o.repeatX + dx + 0.5) * cw;
          const gy = ((y + qr.quiet) * o.repeatY + dy + 0.5) * ch;
          if (o.stroke) ctx.strokeText(glyph, gx, gy);
          ctx.fillText(glyph, gx, gy);
        }
    }),
  );
  return {
    kind: "positioned glyphs",
    fontSizes: Object.fromEntries(sizes),
    width,
    characterOnly: true,
  };
}

// A downloaded HTML sheet keeps the exact PNG artwork plus a selectable text
// version. No executable payload or remote font dependency is introduced.
function htmlSheet(qr, png, text = qr.text) {
  if (!/^data:image\/png;base64,[A-Za-z0-9+/=]+$/.test(png))
    throw new TypeError("Expected a PNG data URL.");
  return `<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Aqrobat print sheet</title><style>body{font:16px/1.6 system-ui;margin:24px;color:#111;background:#fff}main{max-width:760px;margin:auto}img{width:100%;max-width:${qr.recipe.options.width}px;height:auto}pre{overflow:auto;white-space:pre}p{overflow-wrap:anywhere}@page{size:auto;margin:15mm}@media print{img{width:150mm;max-width:150mm}details{display:none}main{max-width:none}}</style><main><h1>Aqrobat</h1><p>Expected payload: ${escapeXml(qr.recipe.payload)}</p><img src="${png}" alt="QR made from glyph artwork"><p>Untested in this print/scanner combination. Requested ECC ${qr.requestedEcc}; actual ECC ${qr.actualEcc}. Printed artwork is 150 mm square including its four-module border. Use the browser Print command.</p><details><summary>Plain text (font and spacing dependent)</summary><pre>${escapeXml(text)}</pre></details></main></html>`;
}

const TEXT_LAYOUT = "aqrobat-text-v1";
// Emoji and East Asian glyphs usually occupy a full em. The receiving font
// still controls advances; this classification is a portable approximation.
const wideGlyph = (s) =>
  /[\p{Emoji_Presentation}\uFE0F\u200D\u3000-\u9FFF\uFF01-\uFF60]/u.test(s);

/** Plain text cannot carry typography. Pack narrow and wide glyphs separately. */
function plainText(qr) {
  const o = qr.recipe.options;
  const wide = qr.palette.map(wideGlyph);
  const mixed = wide.some(Boolean) && !wide.every(Boolean);
  const scale = mixed
    ? Math.max(1, Math.ceil(o.repeatX / 5), Math.ceil(o.repeatY / 3))
    : 1;
  const across = mixed
    ? 5 * scale
    : wide.every(Boolean)
      ? Math.max(1, Math.ceil(o.repeatX / 2), o.repeatY)
      : Math.max(o.repeatX, 2 * o.repeatY);
  const down = mixed ? 3 * scale : o.repeatY;
  const blank = wide.every(Boolean) ? "\u3000" : " ";
  const rows = [];
  for (let y = -qr.quiet; y < qr.modules + qr.quiet; y++) {
    let row = "";
    for (let x = -qr.quiet; x < qr.modules + qr.quiet; x++) {
      const glyph = qr.glyphMatrix[y]?.[x];
      const count = mixed && glyph && wideGlyph(glyph) ? 3 * scale : across;
      row += (glyph ?? blank).repeat(count);
    }
    for (let i = 0; i < down; i++) rows.push(row);
  }
  return {
    text: rows.join("\n") + "\n",
    rows,
    across,
    down,
    blank,
    mixed,
    layout: TEXT_LAYOUT,
  };
}

// Browser-only measurement uses the unchanged image renderer as its source of
// font metrics. This scratch canvas is never embedded in text output.
function textMetrics(qr) {
  const canvas = document.createElement("canvas");
  return render(canvas, qr);
}

/** Real text with inline typography, suitable for HTML clipboard and websites. */
function formattedText(qr, metrics) {
  const o = qr.recipe.options,
    w = o.width;
  const family = escapeXml(fontFamily(o.font));
  const base = `color:#000;background:#fff;font-family:${family};font-weight:700;font-style:normal;letter-spacing:0;text-transform:none;text-decoration:none;direction:ltr;`;
  if (metrics.kind === "text rows") {
    return `<pre data-aqrobat-layout="${TEXT_LAYOUT}" style="${base}margin:0;padding:0;border:0;width:${w}px;font-size:${metrics.fontSize}px;line-height:${metrics.lineHeight}px;white-space:pre;overflow:visible;-webkit-text-stroke:${o.stroke * metrics.fontSize}px #000;">${escapeXml(qr.text)}</pre>`;
  }
  const cell = w / qr.totalModules,
    line = cell / o.repeatY;
  let rows = "";
  for (let y = -qr.quiet; y < qr.modules + qr.quiet; y++) {
    let cells = "";
    for (let x = -qr.quiet; x < qr.modules + qr.quiet; x++) {
      const glyph = qr.glyphMatrix[y]?.[x],
        fs = glyph ? metrics.fontSizes[glyph] : line;
      const content = glyph
        ? Array(o.repeatY)
            .fill(
              `<span style="display:block;height:${line}px;line-height:${line}px;white-space:pre;font-size:${fs}px;-webkit-text-stroke:${o.stroke * fs}px #000;">${escapeXml(glyph.repeat(o.repeatX))}</span>`,
            )
            .join("")
        : "&#160;";
      cells += `<td width="${cell}" height="${cell}" style="padding:0;border:0;width:${cell}px;height:${cell}px;font-size:0;line-height:0;text-align:center;vertical-align:middle;">${content}</td>`;
    }
    rows += `<tr style="height:${cell}px;">${cells}</tr>`;
  }
  return `<table data-aqrobat-layout="${TEXT_LAYOUT}" role="presentation" cellpadding="0" cellspacing="0" width="${w}" style="${base}border:0;border-collapse:collapse;table-layout:fixed;width:${w}px;margin:0;padding:0;line-height:1;"><tbody>${rows}</tbody></table>`;
}

function textDocument(qr, metrics) {
  return `<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Aqrobat text QR</title><style>body{margin:24px;background:white;color:black;font:16px/1.5 system-ui}p{overflow-wrap:anywhere}.scroll{overflow:auto}@page{margin:15mm}@media print{p{font-size:10pt}.scroll{position:relative;overflow:hidden;width:150mm;height:150mm;break-inside:avoid}[data-aqrobat-layout]{position:absolute;left:0;top:0;transform-origin:top left;transform:scale(${(150 * 96) / 25.4 / qr.recipe.options.width})}}</style><h1>Aqrobat · real text</h1><p>Expected payload: ${escapeXml(qr.recipe.payload)}. Font-dependent; scan this exact output before using it.</p><div class="scroll">${formattedText(qr, metrics)}</div><p>This QR contains selectable characters, with no image or hidden solid modules. Keep its inline styles when placing it on a website. Use Print to save a text PDF.</p></html>`;
}
const rtfEscape = (value) =>
  value
    .split("")
    .map((c) => {
      const n = c.charCodeAt(0);
      return n > 127
        ? `\\u${n > 32767 ? n - 65536 : n}?`
        : /[\\{}]/.test(c)
          ? `\\${c}`
          : c;
    })
    .join("");

/** RTF retains font, bold weight, exact line spacing, and fixed tab positions. */
function textRtf(qr, metrics) {
  const o = qr.recipe.options,
    twips = o.width * 15;
  const header = `{\\rtf1\\ansi\\deff0\\uc1{\\fonttbl{\\f0 ${rtfEscape(o.font === "monospace" ? "Menlo" : o.font)};}}{\\colortbl;\\red0\\green0\\blue0;\\red255\\green255\\blue255;}\\paperw${Math.max(12240, Math.ceil(twips + 1440))}\\paperh${Math.max(15840, Math.ceil(twips + 1440))}\\margl720\\margr720\\margt720\\margb720\\f0\\b\\cf1\\highlight2 `;
  if (metrics.kind === "text rows") {
    const fs = Math.round(metrics.fontSize * 1.5),
      line = Math.round(metrics.lineHeight * 15);
    return (
      header +
      `\\fs${fs}\\sl-${line}\\slmult0\\sa0\\sb0 ` +
      qr.rows.map(rtfEscape).join("\\line\n") +
      "\\par}"
    );
  }
  const cell = twips / qr.characterColumns,
    line = twips / qr.characterRows;
  const tabs = Array.from(
    { length: qr.characterColumns },
    (_, i) => `\\tx${Math.round((i + 0.025) * cell)}`,
  ).join("");
  let body = `\\pard\\ql\\sa0\\sb0\\sl-${Math.round(line)}\\slmult0${tabs} `;
  for (let y = -qr.quiet; y < qr.modules + qr.quiet; y++) {
    for (let dy = 0; dy < o.repeatY; dy++) {
      for (let x = -qr.quiet; x < qr.modules + qr.quiet; x++) {
        const glyph = qr.glyphMatrix[y]?.[x];
        // Apple Color Emoji expands advances below 30 pt in TextEdit. Leave
        // extra room for that native fallback; RTF remains font dependent.
        const points = glyph ? metrics.fontSizes[glyph] * 0.75 : 1;
        const fs = Math.max(
          2,
          Math.floor(points * (points < 30 ? 0.75 : 1) * 2),
        );
        for (let dx = 0; dx < o.repeatX; dx++)
          body += `\\fs${fs}\\tab ` + (glyph ? rtfEscape(glyph) : "");
      }
      body += "\\line\n";
    }
  }
  return header + body + "\\par}";
}

function exportName(value) {
  const name = String(value)
    .normalize("NFC")
    .replace(/[\p{Cc}\\/:*?"<>|]/gu, "-")
    .replace(/[. ]+$/g, "")
    .trim()
    .replace(/^\.+$/, "");
  return !name || /^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)/i.test(name)
    ? "aqrobat"
    : Array.from(name).slice(0, 80).join("");
}

const LIBRARY_KEY = "aqrobat-recipes-v1";
const LIBRARY_LIMIT = 20;

function readLibrary(value) {
  if (value === undefined) return [];
  if (!Array.isArray(value) || value.length > LIBRARY_LIMIT)
    throw new TypeError(
      "The saved recipe library is invalid. Export any recoverable recipes before changing it.",
    );
  const ids = new Set();
  return value.map((entry) => {
    if (
      !entry ||
      !/^[a-f0-9-]{36}$/i.test(entry.id) ||
      ids.has(entry.id) ||
      typeof entry.name !== "string" ||
      !entry.name.trim() ||
      entry.name.length > 80
    )
      throw new TypeError("Invalid saved recipe.");
    ids.add(entry.id);
    return {
      id: entry.id,
      name: entry.name,
      recipe: fromRecipe(entry.recipe).recipe,
    };
  });
}

function addRecipe(entries, name, recipe, id) {
  const all = readLibrary(entries);
  if (all.length >= LIBRARY_LIMIT)
    throw new RangeError(
      "The library holds 20 recipes. Export and remove one before adding another.",
    );
  return readLibrary([...all, { id, name: String(name).trim(), recipe }]);
}

// Destination-specific packing. measure() must measure whole strings using
// the destination's actual font, size, letter spacing, and word spacing.
function calibratedText(qr, measure, lineHeight) {
  if (!(lineHeight > 0 && Number.isFinite(lineHeight)))
    throw new RangeError("The editor's line height cannot be measured.");
  const widths = qr.palette.map((g) => measure(g)),
    widest = Math.max(...widths);
  if (!(widest > 0))
    throw new RangeError("The editor's glyphs cannot be measured.");
  // Keep glyphs in the central part of a module. Repetition is adapted to the
  // destination, not the image's pixel size. All cells retain the same matrix.
  const down = Math.max(
      qr.recipe.options.repeatY,
      Math.ceil(widest / lineHeight),
    ),
    cellHeight = lineHeight * down;
  const spaces = [" ", "\u00a0", "\u2009", "\u200a", "\u3000"]
    .map((text) => ({ text, width: measure(text) }))
    .filter((s) => s.width > 0 && Number.isFinite(s.width))
    .sort((a, b) => b.width - a.width);
  if (!spaces.length)
    throw new RangeError("The editor's spaces cannot be measured.");
  // Prefer a nearby cell width the available blanks can express exactly.
  // Keep any horizontal/vertical difference under ten percent; typography can
  // still make the cells slightly rectangular. This is reported in the preview.
  const cellOptions = [];
  for (const a of spaces)
    for (const b of spaces)
      for (let n = 0; n <= 8; n++)
        for (let m = 0; m <= 8; m++) {
          const width = a.width * n + b.width * m;
          if (
            width >= widest &&
            Math.abs(width - cellHeight) <= cellHeight * 0.1
          )
            cellOptions.push(width);
        }
  cellOptions.sort(
    (a, b) => Math.abs(a - cellHeight) - Math.abs(b - cellHeight),
  );
  const cell = cellOptions[0] ?? cellHeight,
    repeats = Object.fromEntries(
      qr.palette.map((g) => {
        let n = 1;
        while (n < 12 && measure(g.repeat(n + 1)) <= cell * 1.01) n++;
        return [g, n];
      }),
    );
  let maxError = 0;
  function pad(row, target) {
    const start = measure(row),
      remaining = target - start;
    const candidates = [{ text: "", error: Math.abs(remaining) }];
    // Compare bounded combinations of two kinds of blank. One greedy blank
    // at a time fails when, for example, two ordinary spaces beat one wide one.
    for (const a of spaces)
      for (const b of spaces) {
        const limit = Math.min(
          64,
          Math.max(0, Math.ceil(remaining / a.width) + 1),
        );
        for (let n = 0; n <= limit; n++) {
          const m = Math.max(
            0,
            Math.min(64, Math.round((remaining - n * a.width) / b.width)),
          );
          const text = a.text.repeat(n) + b.text.repeat(m);
          candidates.push({
            text,
            error: Math.abs(n * a.width + m * b.width - remaining),
          });
        }
      }
    candidates.sort(
      (a, b) => a.error - b.error || a.text.length - b.text.length,
    );
    let best = row,
      error = Math.abs(remaining);
    const checked = new Set();
    for (const option of candidates) {
      if (checked.has(option.text)) continue;
      checked.add(option.text);
      const candidate = row + option.text,
        actual = Math.abs(measure(candidate) - target);
      if (actual + 0.001 < error) {
        error = actual;
        best = candidate;
      }
      if (checked.size >= 8 || error < 0.001) break;
    }
    maxError = Math.max(maxError, error);
    return best;
  }
  const rows = [];
  for (let y = -qr.quiet; y < qr.modules + qr.quiet; y++) {
    let row = "";
    for (let x = -qr.quiet; x < qr.modules + qr.quiet; x++) {
      const glyph = qr.glyphMatrix[y]?.[x],
        i = x + qr.quiet;
      if (glyph) {
        const ink = glyph.repeat(repeats[glyph]);
        row = pad(row, i * cell + (cell - measure(ink)) / 2) + ink;
      }
      row = pad(row, (i + 1) * cell);
    }
    for (let dy = 0; dy < down; dy++) rows.push(row);
  }
  const gridWidth = qr.totalModules * cell;
  const width = Math.max(gridWidth, ...rows.map(measure));
  if (maxError > cell * 0.2)
    throw new RangeError(
      "This font's spaces are too coarse to align the QR. Use a smaller monospace font or formatted insertion.",
    );
  return {
    text: rows.join("\n"),
    rows,
    width,
    gridWidth,
    height: rows.length * lineHeight,
    lineHeight,
    cell,
    cellHeight,
    down,
    maxError,
    repeats,
    layout: "aqrobat-field-v1",
  };
}

/** Runs only after the extension is invoked. No background page observation. */
function openInsertion(entries) {
  // A second invocation may select a different recipe. Close the previous
  // task-owned panel and its listeners before showing the current selection.
  globalThis.__aqrobatCloseInsertion?.();
  if (document.querySelector("aqrobat-insertion")) return;
  const host = document.createElement("aqrobat-insertion"),
    shadow = host.attachShadow({ mode: "open" });
  host.style.cssText =
    "all:initial;position:fixed;right:12px;bottom:12px;z-index:2147483647;max-width:calc(100vw - 24px)";
  shadow.innerHTML = `<style>
    :host{color-scheme:light}*{box-sizing:border-box}section{width:440px;max-width:calc(100vw - 24px);max-height:78vh;overflow:auto;padding:18px;background:#fff;color:#241839;border:2px solid #7951b0;border-radius:16px;box-shadow:0 8px 40px #0004;font:14px/1.4 system-ui;text-align:left}
    h2{font-size:20px;margin:0 0 8px}p{margin:10px 0}button,select,input{font:inherit;padding:8px;border:1px solid #b8a6d0;border-radius:8px;background:#faf7ff;color:#241839}button{cursor:pointer}button:disabled{opacity:.5;cursor:default}label{display:block;margin:10px 0}select{max-width:100%;width:100%}#width{width:100px}#preview{max-height:220px;overflow:auto;border:1px solid #ddd;background:white;color:black;margin:12px 0}#preview:empty{display:none}#preview>pre{margin:0}#close{float:right}small{display:block;color:#675c73}#message{white-space:pre-line}input[type=checkbox]{margin-right:8px}
    </style><section role="dialog" aria-label="Insert an Aqrobat text QR"><button id="close" aria-label="Close insertion panel">✕</button><h2>Insert text QR</h2><label>Saved recipe<select id="recipe"></select></label><p id="payload"></p><p id="target">Click inside the destination text box. Existing text will be preserved; selected text will not be replaced.</p><label>Insertion<select id="mode"><option value="formatted">Formatted text · rich editors</option><option value="plain">Measured plain text · destination font</option></select></label><label id="width-label">Formatted width <input id="width" type="number" value="328" min="200" max="1536" step="1"> px</label><p id="message" role="status"></p><div id="preview" aria-label="Insertion preview"></div><button id="prepare">Preview in this field</button> <button id="insert" disabled>Insert at cursor</button><p><small>Layout preview is not a scan test. Review the saved/sent result too. This extension never sends an email or submits a form.</small></p></section>`;
  document.documentElement.append(host);
  const $i = (id) => shadow.getElementById(id);
  let field = null,
    snapshot = null,
    prepared = null,
    revision = 0,
    picking = true;
  for (const entry of entries) {
    const option = document.createElement("option");
    option.value = entry.id;
    option.textContent = entry.name;
    $i("recipe").append(option);
  }
  function selected() {
    return entries.find((e) => e.id === $i("recipe").value);
  }
  function describe() {
    $i("payload").textContent = selected()
      ? `Payload: ${selected().recipe.payload}`
      : "No saved recipes. Open the Aqrobat generator, load or create a recipe, and choose Save in extension.";
  }
  describe();
  $i("prepare").disabled = !entries.length;
  function invalidate() {
    revision++;
    prepared = null;
    $i("insert").disabled = true;
    $i("preview").replaceChildren();
  }
  function close() {
    invalidate();
    document.removeEventListener("click", choose, true);
    document.removeEventListener("keydown", escape, true);
    host.remove();
    if (globalThis.__aqrobatCloseInsertion === close)
      delete globalThis.__aqrobatCloseInsertion;
  }
  globalThis.__aqrobatCloseInsertion = close;
  function escape(e) {
    if (e.key === "Escape") close();
  }
  $i("close").onclick = close;
  document.addEventListener("keydown", escape, true);
  function editable(node) {
    if (!(node instanceof Element)) return null;
    if (node instanceof HTMLTextAreaElement || node instanceof HTMLInputElement)
      return node;
    if (!node.isContentEditable) return null;
    let root = node;
    while (root.parentElement?.isContentEditable) root = root.parentElement;
    return root;
  }
  function choose(e) {
    if (!e.isTrusted || e.composedPath().includes(host) || !picking) return;
    const candidate = e.composedPath().map(editable).find(Boolean);
    if (!candidate) return;
    invalidate();
    field = candidate;
    const plain =
      field instanceof HTMLTextAreaElement ||
      field.contentEditable === "plaintext-only";
    $i("mode").value = plain ? "plain" : "formatted";
    $i("mode").disabled = plain;
    $i("width-label").hidden = plain;
    $i("target").textContent =
      `Destination: ${field.tagName.toLowerCase()}${field.getAttribute("aria-label") ? " · " + field.getAttribute("aria-label") : ""}. Click in another field to switch. Insertion uses an empty cursor; selected text is preserved.`;
    $i("message").textContent =
      "Choose your recipe, then preview. Nothing has been inserted.";
    // Selection settles after the click's default action.
    setTimeout(() => {
      if (field !== candidate) return;
      try {
        snapshot = capture();
      } catch (error) {
        snapshot = null;
        $i("message").textContent = error.message;
      }
    }, 0);
  }
  document.addEventListener("click", choose, true);
  function capture() {
    if (!field?.isConnected)
      throw new Error("Click inside a destination field first.");
    if (field instanceof HTMLInputElement)
      throw new Error(
        "Single-line and password fields cannot hold a QR. Choose a multiline text box or rich editor.",
      );
    if (
      field.matches(":disabled,[readonly]") ||
      field.closest("[inert]") ||
      field.getAttribute("aria-readonly") === "true"
    )
      throw new Error("This editor is read-only.");
    if (field instanceof HTMLTextAreaElement) {
      if (field.selectionStart !== field.selectionEnd)
        throw new Error(
          "Place an empty cursor first. Aqrobat preserves selected text.",
        );
      return { value: field.value, position: field.selectionStart };
    }
    if (!field.isContentEditable)
      throw new Error("This editor is no longer editable.");
    const selection = document.getSelection();
    if (!selection?.rangeCount)
      throw new Error("Place a cursor inside the editor.");
    const range = selection.getRangeAt(0);
    if (!field.contains(range.startContainer) || !range.collapsed)
      throw new Error(
        "Place an empty cursor inside the editor. Selected text is preserved.",
      );
    if (
      range.startContainer.parentElement?.closest('[contenteditable="false"]')
    )
      throw new Error("This part of the editor is not editable.");
    return { value: field.innerHTML, range: range.cloneRange() };
  }
  function contentWidth() {
    const css = getComputedStyle(field);
    return (
      field.clientWidth -
      parseFloat(css.paddingLeft) -
      parseFloat(css.paddingRight)
    );
  }
  const fontKeys = [
    "fontFamily",
    "fontSize",
    "fontWeight",
    "fontStyle",
    "fontStretch",
    "fontVariant",
    "fontKerning",
    "fontFeatureSettings",
    "fontVariationSettings",
    "fontVariantLigatures",
    "letterSpacing",
    "wordSpacing",
    "lineHeight",
  ];
  const textKeys = [
    ...fontKeys,
    "whiteSpace",
    "textTransform",
    "direction",
    "writingMode",
    "textAlign",
    "textIndent",
  ];
  function caretStyle() {
    const node = snapshot?.range?.startContainer;
    return getComputedStyle(
      node ? (node instanceof Element ? node : node.parentElement) : field,
    );
  }
  function fingerprint() {
    const s = getComputedStyle(field);
    const caret = caretStyle();
    return [
      contentWidth(),
      ...textKeys.map((key) => s[key]),
      ...textKeys.map((key) => caret[key]),
      field instanceof HTMLTextAreaElement ? field.maxLength : "",
    ].join("|");
  }
  function measurePlain(qr) {
    const css = getComputedStyle(field);
    const caret = caretStyle();
    if (textKeys.some((key) => caret[key] !== css[key]))
      throw new Error(
        "Plain insertion needs uniform typography at the cursor. Use formatted insertion or the editor’s own plain/code mode.",
      );
    if (
      css.direction !== "ltr" ||
      css.writingMode !== "horizontal-tb" ||
      css.textTransform !== "none" ||
      !["left", "start"].includes(css.textAlign) ||
      parseFloat(css.textIndent) !== 0
    )
      throw new Error(
        "Plain insertion needs left-aligned horizontal text, no indentation, and no automatic case conversion.",
      );
    if (!/pre/.test(css.whiteSpace))
      throw new Error(
        "This editor collapses spaces. Use formatted insertion, or its code/preformatted mode.",
      );
    const probe = document.createElement("pre"),
      span = document.createElement("span");
    probe.style.cssText =
      "all:initial;position:fixed;left:-100000px;top:0;white-space:pre;visibility:hidden;width:max-content;max-width:none;padding:0;margin:0;border:0;";
    for (const key of fontKeys) probe.style[key] = css[key];
    probe.append(span);
    shadow.append(probe);
    try {
      span.textContent = "M\nM";
      const range = document.createRange();
      range.selectNodeContents(span);
      const rects = Array.from(range.getClientRects()).filter(
        (r) => r.width > 0,
      );
      const lineHeight =
        rects.length >= 2
          ? rects.at(-1).top - rects[0].top
          : parseFloat(css.lineHeight);
      const cache = new Map();
      const measure = (text) => {
        if (!cache.has(text)) {
          span.textContent = text;
          cache.set(text, span.getBoundingClientRect().width);
        }
        return cache.get(text);
      };
      // Fail before packing if even one glyph per module cannot fit.
      const minCell =
        lineHeight *
        Math.max(
          qr.recipe.options.repeatY,
          Math.ceil(Math.max(...qr.palette.map(measure)) / lineHeight),
        );
      if (minCell * qr.totalModules > contentWidth() + 0.5)
        throw new Error(
          `The QR needs at least ${Math.ceil(minCell * qr.totalModules)} px at this font; the field has ${Math.floor(contentWidth())} px. Widen the field or choose a smaller font in the editor.`,
        );
      const packed = calibratedText(qr, measure, lineHeight);
      return { ...packed, css };
    } finally {
      probe.remove();
    }
  }
  $i("recipe").onchange = () => {
    describe();
    invalidate();
  };
  for (const id of ["mode", "width"])
    $i(id).onchange = () => {
      invalidate();
      $i("width-label").hidden = $i("mode").value === "plain";
    };
  $i("prepare").onclick = async (click) => {
    if (!click.isTrusted) return;
    invalidate();
    const preparing = revision;
    try {
      if (!field || !snapshot)
        throw new Error("Click inside a destination field first.");
      if (
        !field.isConnected ||
        (field instanceof HTMLTextAreaElement
          ? field.value
          : field.innerHTML) !== snapshot.value
      )
        throw new Error(
          "The draft changed. Click inside the field again before previewing.",
        );
      if (
        field instanceof HTMLInputElement ||
        field.matches(":disabled,[readonly]") ||
        field.closest("[inert]")
      )
        throw new Error("Choose an editable multiline field.");
      // A user may move the cursor with the keyboard after choosing the field.
      // Refresh it without changing the draft or replacing a selection.
      if (field instanceof HTMLTextAreaElement) snapshot = capture();
      else {
        const selection = document.getSelection();
        if (selection?.rangeCount && field.contains(selection.anchorNode))
          snapshot = capture();
      }
      await document.fonts.ready;
      if (preparing !== revision || !host.isConnected) return;
      if (
        (field instanceof HTMLTextAreaElement
          ? field.value
          : field.innerHTML) !== snapshot.value
      )
        throw new Error(
          "The draft changed while fonts loaded. Click inside the field and preview again.",
        );
      const source = fromRecipe(selected().recipe);
      let html = null,
        packed = null;
      if ($i("mode").value === "formatted") {
        const width = Number($i("width").value);
        if (!Number.isInteger(width) || width < 200 || width > 1536)
          throw new Error("Choose a formatted width from 200 to 1536 px.");
        if (width > contentWidth())
          throw new Error(
            `The ${width} px QR does not fit this ${Math.floor(contentWidth())} px field. Reduce the formatted width or widen the editor.`,
          );
        const qr = fromRecipe({
          ...source.recipe,
          options: { ...source.recipe.options, width },
        });
        html = formattedText(qr, textMetrics(qr));
        $i("preview").innerHTML = html;
      } else {
        packed = measurePlain(source);
        if (packed.text.length > 200000)
          throw new Error("The plain output is too large for safe insertion.");
        if (
          field instanceof HTMLTextAreaElement &&
          field.maxLength >= 0 &&
          snapshot.value.length + packed.text.length + 2 > field.maxLength
        )
          throw new Error(
            "The QR exceeds this field's character limit. Nothing will be shortened.",
          );
        if (packed.width > contentWidth() + 0.5)
          throw new Error(
            "The QR would wrap in this field. Widen it or choose a smaller editor font.",
          );
        const pre = document.createElement("pre");
        pre.textContent = packed.text;
        for (const key of fontKeys) pre.style[key] = packed.css[key];
        pre.style.whiteSpace = "pre";
        pre.style.width = `${packed.width}px`;
        pre.style.margin = "0";
        $i("preview").append(pre);
      }
      prepared = { html, packed, fingerprint: fingerprint() };
      $i("insert").disabled = false;
      $i("message").textContent = packed
        ? `Measured ${Math.ceil(packed.width)} × ${Math.ceil(packed.height)} px; maximum spacing error ${packed.maxError.toFixed(2)} px per boundary. Cells may be slightly rectangular; repetition adapts to this font. Full height may scroll. Scan the inserted result before using it.`
        : "This preview contains real styled text. The editor may remove styles; check the inserted and saved result.";
    } catch (error) {
      $i("message").textContent = error.message;
    }
  };
  $i("insert").onclick = async (click) => {
    if (!click.isTrusted) return;
    try {
      if (!prepared || !field?.isConnected)
        throw new Error("Preview the field first.");
      if (
        field.matches(":disabled,[readonly]") ||
        field.closest("[inert]") ||
        field.getAttribute("aria-readonly") === "true"
      )
        throw new Error("This editor is now read-only. Nothing was inserted.");
      if (
        (field instanceof HTMLTextAreaElement
          ? field.value
          : field.innerHTML) !== snapshot.value ||
        fingerprint() !== prepared.fingerprint
      )
        throw new Error(
          "The draft or typography changed. Click inside the field and preview again.",
        );
      const ready = prepared;
      const originalLayouts = new Set(
        field.querySelectorAll("[data-aqrobat-layout]"),
      );
      let expectedPlain = null;
      field.focus();
      if (field instanceof HTMLTextAreaElement)
        field.setSelectionRange(snapshot.position, snapshot.position);
      else {
        const selection = document.getSelection();
        selection.removeAllRanges();
        selection.addRange(snapshot.range);
      }
      // Give controlled editors a cancellable event. Never bypass a veto with
      // direct value/DOM assignment. execCommand preserves Chrome's undo history.
      const event = new InputEvent("beforeinput", {
        bubbles: true,
        composed: true,
        cancelable: true,
        inputType: "insertFromPaste",
        data: ready.packed?.text ?? null,
      });
      if (!field.dispatchEvent(event))
        throw new Error(
          "The editor declined insertion. Its draft is unchanged.",
        );
      if (
        (field instanceof HTMLTextAreaElement
          ? field.value
          : field.innerHTML) !== snapshot.value
      )
        throw new Error(
          "The editor changed its draft during the insertion event. Preview again.",
        );
      if (fingerprint() !== ready.fingerprint)
        throw new Error(
          "The editor changed its typography during insertion. Preview again.",
        );
      const active = field.getRootNode().activeElement;
      const cursor = capture();
      const sameCursor =
        field instanceof HTMLTextAreaElement
          ? cursor.position === snapshot.position
          : cursor.range.startContainer === snapshot.range.startContainer &&
            cursor.range.startOffset === snapshot.range.startOffset;
      if (!(active === field || field.contains(active)) || !sameCursor)
        throw new Error(
          "The editor moved the insertion cursor. Click inside the intended field and preview again.",
        );
      let success;
      if (ready.html)
        success = document.execCommand("insertHTML", false, ready.html);
      else {
        const prefix =
          field instanceof HTMLTextAreaElement &&
          snapshot.position > 0 &&
          snapshot.value[snapshot.position - 1] !== "\n"
            ? "\n"
            : "";
        const suffix = "\n";
        if (field instanceof HTMLTextAreaElement)
          expectedPlain =
            snapshot.value.slice(0, snapshot.position) +
            prefix +
            ready.packed.text +
            suffix +
            snapshot.value.slice(snapshot.position);
        success = document.execCommand(
          "insertText",
          false,
          prefix + ready.packed.text + suffix,
        );
      }
      if (!success)
        throw new Error(
          "This editor did not accept insertion. Use Text HTML/RTF or its own code-block feature instead.",
        );
      prepared = null;
      $i("insert").disabled = true;
      picking = false;
      document.removeEventListener("click", choose, true);
      await new Promise(requestAnimationFrame);
      const insertedLayout = Array.from(
        field.querySelectorAll("[data-aqrobat-layout]"),
      ).find((node) => !originalLayouts.has(node));
      const changed =
        expectedPlain !== null
          ? field.value !== expectedPlain
          : ready.html &&
            (!insertedLayout ||
              Math.abs(
                insertedLayout.getBoundingClientRect().width -
                  Number($i("width").value),
              ) > 1 ||
              Math.abs(
                insertedLayout.getBoundingClientRect().height -
                  Number($i("width").value),
              ) > 2);
      $i("message").textContent = changed
        ? "The editor changed the inserted text or layout. Inspect the draft and use Undo (⌘Z / Ctrl+Z) if needed. Try its own code-block feature or Text HTML/RTF. Formatting is not verified here."
        : "Inserted. Review the actual field and scan it. Use Undo (⌘Z / Ctrl+Z) to remove this insertion. Saved/sent formatting may differ; no scan success is assumed.";
    } catch (error) {
      invalidate();
      $i("message").textContent = error.message;
    }
  };
}


globalThis.__aqrobatOpenInsertion = openInsertion;
})();
